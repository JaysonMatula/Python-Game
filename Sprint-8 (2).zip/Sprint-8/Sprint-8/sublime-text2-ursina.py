from ursina import*

app=Ursina()

Entity(model="quad", texture="download.jpg", position=(0,0,0), scale=5)


wall_4=Entity(model="cube", collider="box", position=(5, -3, 7), scale=(0.2, 40, 30), rotation=(0,90,90),
	texture="flat", texture_scale=(10,10), color=color.gray)

Entity(parent=ground, model = "quad", texture="car.jpg", position=(25,1.95,0), scale=(8, 4, 4), rotation=(0,90,0),double_sided=True)

Entity(parent=ground, model = "cube", position=(25,1.95,0), scale=(.17, 2, 4), rotation=(0,90,0),double_sided=True)


Entity(model = "quad", texture="night2.jpg", position=(100,0,0), scale=(200, 200, 200), collider="box", rotation=(0,90,0),double_sided=True)

Entity(model = "quad", texture="night2.jpg", position=(0,100,0), scale=(200, 200, 200), collider="box", rotation=(90,90,0),double_sided=True)


wall_13=Entity(model="cube", collider="box", position=(5, 9.5, 7), scale=(0.2, 40, 30), rotation=(0,90,90),
	texture="flat", texture_scale=(10,10), color=color.gray)

gun=Entity(model='sphere', parent=camera.ui, scale=(.08, .1, 4), color=color.gray, position=(.3, -.1, -7),
	rotation=(-3.5, -10, -5))

app.run()



gun=Entity(model='gun.obj', texture='gun.obj', parent=camera.ui, scale=.08, color=color.gray, position=(.3, -.2),
	rotation=(-5, -10, -10))

gun=Entity(model='cube', parent=camera.ui, scale=(0.08, .3, .4), color=color.black, position=(.3, -.2),
	rotation=(-5, -10, -10))

gun=Entity(model='cube', parent=camera.ui, scale=(.08, .1, 2), color=color.gray, position=(.3, -.1, 1),
	rotation=(-3.5, -10, -5))





gun=Entity(model='cube', parent=camera.ui, scale=(0.08, .3, .4), color=color.black, position=(.3, -.2),
	rotation=(-5, -10, -10))

gun=Entity(model='cube', parent=camera.ui, scale=(.08, .1, 2), color=color.gray, position=(.3, -.1, 1),
	rotation=(-3.5, -10, -5))

def update(self):
	if distance(self.player) > 20:
		self.position += ((self.player.position + self.random) - self.position).normalized() * self.move_speed * time.dt

	self.look_at(self.player)
	self.rotation_z = 0

	Animation('bullet', model='cube', parent=camera.ui, scale=1, color=color.black, position=(.3, -.2, -.5), texture="brick",
rotation=(-5, -10, -10))



gun=Entity(model="gun.obj", parent=camera.ui, scale=.08, color=color.gray, position=(.3, -.2, -.5), texture="brick",
rotation=(-5, -10, -10))


def input(key):
	if key=="left mouse down":
		Animation('spark', model='cube', texture='spark_01.png', parent=camera.ui, fps=5, scale=.1, position=(.19, -.03), loop=False )
		
class Wasp(Button):
	def __init__(self, x, y, z):
		super().__init__(
			parent=scene,
			model="wasp.obj",
			scale=.5,
			position=(30,10,z),
			rotation=(0, 90, 90),
			collider="box"
			)


num=1
wasps=[None]*num
for i in range(num):
	wx=uniform(-12, -7)
	wy=uniform(.1, 1.8)
	wz=uniform(.8, 3.8)
	wasps[i]=Wasp(wx, wy, wz)
	wasps[i].animate_x(wx+.5, duration=.2, loop=True)
