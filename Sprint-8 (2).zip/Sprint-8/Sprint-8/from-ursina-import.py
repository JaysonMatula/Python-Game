from ursina import

app=Ursina()

mushroom=Entity(model="assets/pumpkin.obj")

app.run()