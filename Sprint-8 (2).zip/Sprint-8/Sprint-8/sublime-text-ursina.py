from ursina import *
from random import uniform
from ursina.prefabs.first_person_controller import FirstPersonController







app=Ursina()

Sky()
player=FirstPersonController(y=2, origin_y=-.5)
ground=Entity(model='plane', scale=(700, 1, 700), color=color.gray, texture="white_cube",
	texture_scale=(100, 100), collider='box')



structure_4=Entity(model="cube", collider="box", position=(5, -3, 7), scale=(0.2, 40, 30), rotation=(0,90,90),
	texture="flat", texture_scale=(10,10), color=color.gray)


structure_5=Entity(model="cube", collider="box", position=(-10, 0, 10), scale=(1, 20, 32), rotation=(0,0,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_6=Entity(model="cube", collider="box", position=(20, 0, 20), scale=(1, 20, 13), rotation=(1,0,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_7=Entity(model="cube", collider="box", position=(20, 0, 0), scale=(1, 20, 13), rotation=(1,0,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_8=Entity(model="cube", collider="box", position=(5, 0, 26), scale=(1, 20, 30), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_8=Entity(model="cube", collider="box", position=(0.5, 0, -6), scale=(1, 20, 22), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_9=Entity(model="cube", collider="box", position=(5, 0, -6), scale=(0.8, 2, 30), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_10=Entity(model="cube", collider="box", position=(5, 0, -6), scale=(0.8, 4, 17), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_11=Entity(model="cube", collider="box", position=(15, 7, -6), scale=(0.8, 1.5, 11.5), rotation=(25,90,0),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_12=Entity(model="cube", collider="box", position=(5, 10, 7), scale=(1, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_13=Entity(model="cube", collider="box", position=(5, 9.5, 7), scale=(0.2, 40, 30), rotation=(0,90,90),
	texture="flat", texture_scale=(10,10), color=color.gray)

platform_1=Entity(model="cube", collider="box", position=(-70, -8, 50), scale=(20, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_2=Entity(model="cube", collider="box", position=(-70, 6, 80), scale=(20, -20, 30), rotation=(130,0,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_3=Entity(model="cube", collider="box", position=(-120, 14, 100), scale=(20, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_4=Entity(model="cube", collider="box", position=(-90, 12, 100), scale=(20, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_5=Entity(model="cube", collider="box", position=(-150, 40, 120), scale=(5, 0, 150), rotation=(55,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_6=Entity(model="cube", collider="box", position=(-150, 57, 124), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_7=Entity(model="cube", collider="box", position=(-150, 59, 126), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 61, 128), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 63, 130), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 65, 132), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 67, 134), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 69, 136), scale=(5, 0, 150), rotation=(0,90,0),
	texture="brick", texture_scale=(10,10), color=color.gray)

platform_8=Entity(model="cube", collider="box", position=(-150, 69, 136), scale=(5, 0, 150), rotation=(0,90,120),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_15=Entity(model="cube", collider="box", position=(80, 10, 28), scale=(40, 100, 60), rotation=(0,90,0),
	texture="building.jpg", texture_scale=(10,10), color=color.gray)

structure_16=Entity(model="cube", collider="box", position=(70, 10, 80), scale=(80, 40, 30), rotation=(0,0,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

boundary_1=Entity(model="cube", collider="box", position=(100, 0, 0), scale=(10, 1, 200), rotation=(0,0,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

boundary_2=Entity(model="cube", collider="box", position=(-100, 0, 0), scale=(10, 1, 200), rotation=(0,0,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

car=Entity(model = "cube", position=(25,1,0), color=color.pink, scale=(8, 2, 4), rotation=(0,90,0),double_sided=True) 

car=Entity(model= 'sphere', position=(25,1,0), 
color=color.black, scale=(8, 6, 4), rotation=(0,0,0),double_sided=True)

structure_17=Entity(model="cube", collider="box", position=(260, 10, 130, 10), scale=(40, 100, 60), rotation=(0,90,0),
	texture="building.jpg", texture_scale=(10,10), color=color.gray)

boundary_3=Entity(model="cube", collider="box", position=(0, 0, -100), scale=(10, 1, 200), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

boundary_4=Entity(model="cube", collider="box", position=(90, 0, 100), scale=(10, 1, 200), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_18=Entity(model="cube", collider="box", position=(-200, -20, 130, 10), scale=(40, 100, 60), rotation=(0,90,0),
	texture="building.jpg", texture_scale=(10,10), color=color.gray)

structure_19=Entity(model="cube", collider="box", position=(-400, -20, 130, 10), scale=(40, 100, 60), rotation=(0,90,0),
	texture="building.jpg", texture_scale=(10,10), color=color.brown)

structure_20=Entity(model="cube", collider="box", position=(-80, 10, -60), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_21=Entity(model="cube", collider="box", position=(-120, 20, -120), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_22=Entity(model="cube", collider="box", position=(-50, 20, -120), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_23=Entity(model="cube", collider="box", position=(-50, 20, 120), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_24=Entity(model="cube", collider="box", position=(-110, 20, 50), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_25=Entity(model="cube", collider="box", position=(-180, 20, 120), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_26=Entity(model="cube", collider="box", position=(30, 20, 130), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_27=Entity(model="cube", collider="box", position=(-10, 20, 200), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.red)

structure_28=Entity(model="cube", collider="box", position=(-30, 20, 230), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_28=Entity(model="cube", collider="box", position=(-80, 10, 250), scale=(100, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_29=Entity(model="cube", collider="box", position=(-130, 80, 280), scale=(300, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

the_spiral_1=Entity(model="cube", collider="box", position=(-250, 140, 280), scale=(100000, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.white)

the_spiral_2=Entity(model="cube", collider="box", position=(-350, 140, 280), scale=(500, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.white)

structure_30=Entity(model="cube", collider="box", position=(-300, 10, 240), scale=(180, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_31=Entity(model="cube", collider="box", position=(120, 20, -120), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_32=Entity(model="cube", collider="box", position=(120, 20, -40), scale=(70, 40, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_33=Entity(model="cube", collider="box", position=(-10, 20, -80), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_34=Entity(model="cube", collider="box", position=(80, 10, -80), scale=(30, 30, 30), rotation=(90,0,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_35=Entity(model="cube", collider="box", position=(-30, 20, -180), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_36=Entity(model="cube", collider="box", position=(30, 20, -180), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_37=Entity(model="cube", collider="box", position=(80, 10, -180), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_38=Entity(model="cube", collider="box", position=(220, 10, 100), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_39=Entity(model="cube", collider="box", position=(220, 10, -100), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.white)

structure_40=Entity(model="cube", collider="box", position=(220, 10, 20), scale=(70, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_41=Entity(model="cube", collider="box", position=(280, 10, 20), scale=(400, 60, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.brown)

structure_42=Entity(model="cube", collider="box", position=(340, 10, 20), scale=(40, 600, 30), rotation=(0,90,90),
	texture="brick", texture_scale=(10,10), color=color.gray)

structure_43=Entity(model="cube", collider="box", position=(60, 10, -20), scale=(30, 15, 30), rotation=(90,0,90),
	texture="brick", texture_scale=(10,10), color=color.rgb(255, 128, 0))

structure_44=Entity(model="cube", collider="box", position=(40, 10, -200), scale=(30, 30, 30), rotation=(90,0,90),
	texture="brick", texture_scale=(10,10), color=color.white)

structure_45=Entity(model="cube", collider="box", position=(0, 10, -250), scale=(30, 30, 60), rotation=(90,0,90),
	texture="brick", texture_scale=(10,10), color=color.white)





app.run()